from __future__ import annotations
from typing import List, Tuple
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

class CrossEncoderReranker:
    def __init__(self, model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2", device: str | None = None):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.model.eval()

    @torch.no_grad()
    def rerank(self, query: str, candidates: List[str], top_k: int) -> List[Tuple[int, float]]:
        if not candidates:
            return []
        pairs = [(query, c) for c in candidates]
        enc = self.tokenizer(pairs, padding=True, truncation=True, return_tensors="pt", max_length=384)
        enc = {k: v.to(self.device) for k, v in enc.items()}
        logits = self.model(**enc).logits.squeeze(-1)
        scores = logits.detach().cpu().float().tolist()
        order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
        return [(i, float(scores[i])) for i in order]
