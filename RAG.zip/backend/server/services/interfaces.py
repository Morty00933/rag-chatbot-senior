from abc import ABC, abstractmethod
from typing import List, Tuple

class Embeddings(ABC):
    @abstractmethod
    def embed(self, texts: List[str]) -> List[List[float]]: ...

class LLM(ABC):
    @abstractmethod
    async def generate(self, prompt: str) -> str: ...

class VectorStore(ABC):
    @abstractmethod
    def upsert(self, ids: List[str], vectors: List[List[float]], metadatas: List[dict]) -> None: ...
    @abstractmethod
    def search(self, query: List[float], top_k: int) -> List[Tuple[dict, float]]: ...