from __future__ import annotations
from typing import List, Dict
import uuid
from .interfaces import Embeddings, VectorStore

# Неймспейс для детерминированного UUIDv5:
_UUID_NS = uuid.NAMESPACE_URL
_UUID_SALT = "rag-chatbot-senior/point"  # чтобы не пересекаться с иными системами

def _to_point_id(chunk_id: str) -> str:
    """
    Делает валидный для Qdrant point_id (UUIDv5) из произвольного chunk_id.
    Детеминированный: одинаковый chunk_id -> одинаковый UUID.
    """
    name = f"{_UUID_SALT}:{chunk_id}"
    return str(uuid.uuid5(_UUID_NS, name))

class Indexer:
    def __init__(self, embeddings: Embeddings, vectorstore: VectorStore):
        self.embeddings = embeddings
        self.vectorstore = vectorstore

    def upsert_chunks(self, chunks: List[str], metas: List[Dict]) -> int:
        if not chunks:
            return 0

        # 1) Эмбеддинги
        vectors = self.embeddings.embed(chunks)

        # 2) point_id как UUIDv5, оригинальный chunk_id кладём в payload
        ids: List[str] = []
        payloads: List[Dict] = []
        for i, m in enumerate(metas):
            orig_chunk_id = str(m.get("chunk_id", f"missing:{i}"))
            point_id = _to_point_id(orig_chunk_id)
            # гарантируем наличие оригинала в payload для отладок/обратной связи:
            m = dict(m)
            m["chunk_id"] = orig_chunk_id
            m["point_id"] = point_id
            ids.append(point_id)
            payloads.append(m)

        # 3) Апсерт
        self.vectorstore.upsert(ids=ids, vectors=vectors, payloads=payloads)
        return len(chunks)
