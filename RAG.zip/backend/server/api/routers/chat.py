from __future__ import annotations
from typing import List, Tuple, Dict
from fastapi import APIRouter, HTTPException

from ...services.embeddings import get_embeddings
from ...services.vectorstore import get_vectorstore
from ...services.retriever import HybridRetriever
from ...services.llm import get_llm
from ...schemas.chat import ChatRequest, ChatResponse, Reference
from ...db import get_docstore
from ...services.reranker import CrossEncoderReranker
from ...services.prompting import get_system_instruction, build_user_prompt

router = APIRouter()

def _collect_contexts_and_refs(
    candidates: List[Tuple[str, Dict, float]],
    max_ctx: int = 6
) -> Tuple[List[str], List[Reference]]:
    docstore = get_docstore()
    contexts: List[str] = []
    refs: List[Reference] = []

    for idx, (chunk_id, payload, score) in enumerate(candidates[:max_ctx], start=1):
        rec = docstore.get(chunk_id)  # {"meta": {...}, "text": "..."}
        if not rec or "text" not in rec:
            continue
        text: str = rec["text"]
        meta: Dict = rec.get("meta") or {}
        filename = meta.get("filename", "unknown")
        doc_id = meta.get("document_id", "unknown")
        chunk_idx = int(meta.get("chunk_ord", 0))

        contexts.append(text)
        refs.append(
            Reference(
                document_id=doc_id,
                filename=filename,
                score=float(score),
                chunk_ord=chunk_idx,
                preview=text[:200]
            )
        )
    return contexts, refs

@router.post("/chat", response_model=ChatResponse, tags=["chat"])
async def chat(req: ChatRequest) -> ChatResponse:
    q = (req.question or "").strip()
    if not q:
        raise HTTPException(status_code=400, detail="question is empty")

    # 1) Ретрив кандидатов
    retriever = HybridRetriever(get_embeddings(), get_vectorstore(), top_pool=24)
    first_hits = retriever.search(q, top_k=12)  # расширяем пул, сузим после rerank

    # 2) Докачка текстов + черновые референсы
    contexts_raw, refs_raw = _collect_contexts_and_refs(first_hits, max_ctx=len(first_hits))

    if not contexts_raw:
        # Нет контекста — всё равно генерируем честный ответ по системному промпту
        sys_instr = get_system_instruction()
        prompt = build_user_prompt(q, [], sys_instr)
        answer = await get_llm().generate(prompt)
        answer = (answer or "").strip() or "я не знаю"
        return ChatResponse(answer=answer, references=[])

    # 3) Rerank Cross-Encoder
    reranker = CrossEncoderReranker()
    scores = reranker.score_pairs([q] * len(contexts_raw), contexts_raw)
    order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

    k = min(6, len(order))
    contexts = [contexts_raw[i] for i in order[:k]]
    refs = [refs_raw[i] for i in order[:k]]

    # 4) Системная инструкция из шаблона
    sys_instr = get_system_instruction()  # читает ENV и шаблоны

    # 5) Генерация
    prompt = build_user_prompt(q, contexts, sys_instr)
    answer = await get_llm().generate(prompt)
    answer = (answer or "").strip() or "я не знаю"

    return ChatResponse(answer=answer, references=refs)
